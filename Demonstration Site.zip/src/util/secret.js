

export const SERVICE_ID="service_w5sij0w"
export const TEMPLATE_ID="template_a8vba5g"
export const PUBLIC_KEY="Jn8pFve8N_gjjuYy7"